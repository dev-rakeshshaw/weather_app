from tkinter import *
import tkinter as tk
from geopy.geocoders import Nominatim
from tkinter import ttk, messagebox
from timezonefinder import TimezoneFinder
from datetime import datetime
import requests
import pytz
from PIL import Image,ImageTk
from urllib.request import urlopen



root = Tk()
root.title("Weather App")
root.geometry("900x500+300+200")
root.resizable(False,False)

def getWeather():
    try:
        city = textfield.get() #Get the city name from the text field

        #Finding the Latitude and Longitude for the City
        geolocator = Nominatim(user_agent="geoapiExercises")
        location=geolocator.geocode(city)
        obj = TimezoneFinder()
        result=obj.timezone_at(lng=location.longitude,lat=location.latitude)
        
        #Finding the Current date and time for the City using Lat. snd Long.
        home = pytz.timezone(result)
        local_time=datetime.now(home)
        current_time=local_time.strftime("%d/%m/%Y \n %I:%M %p %Z")
        clock.config(text=f"{current_time}")
        # name.config(text="CURRENT TIME")

        #open_weather_api
        api = "https://api.openweathermap.org/data/2.5/weather?q="+city+"&appid=1158548287d8cbd4e74fa8bde4830244"
        
        #Fetching the required data from the open_weather_api
        json_data=requests.get(api).json()
        condition = json_data['weather'][0]['main']
        description = json_data['weather'][0]['description']
        feels_like=int(json_data['main']['feels_like']-273.15)
        temp = int(json_data['main']['temp']-273.15)
        pressure = json_data['main']['pressure']
        humidity = json_data['main']['humidity']
        wind = json_data['wind']['speed']
        weather_icon=json_data['weather'][0]['icon']
        weather_icon_url = "https://openweathermap.org/img/w/"+weather_icon+".png"
        u = urlopen(weather_icon_url)
        raw_data=u.read()
        u.close()
        
        #Fitting the fetched data to their respective labels
        t.config(text=(temp,"°"))
        c.config(text=("FEELS","LIKE",feels_like,"°","|",condition))
        w.config(text=(wind,'m/s'))
        h.config(text=(humidity,"%"))
        d.config(text=description.title())
        p.config(text=(pressure,"hPa"))


        photo = ImageTk.PhotoImage(data=raw_data)
        weather_logo=Label(image=photo,bg="#404040")
        weather_logo.image=photo
        weather_logo.pack()
        weather_logo.place(x=800,y=180)


    except Exception as e:
        messagebox.showerror("Weather App","Invalid Entry!!")


#Creating the elements of the app

#search box
search_image=PhotoImage(file="./assests/search.png")
myimage=Label(image=search_image)
myimage.place(x=20,y=20)

textfield=tk.Entry(root,justify="center",width=17,font=("poppins",25,"bold"),bg="white",border=0,fg="#404040")
textfield.place(x=55,y=39)
textfield.focus()

search_icon=PhotoImage(file="./assests/search_icon.png")
myimage_icon=Button(image=search_icon,borderwidth=0,cursor="hand2",bg="#404040",command=getWeather)
myimage_icon.place(x=400,y=34)

#App Title Box
App_Title_label = Label(root,text="Current Weather Report",font=("Helvetica",15,"bold"),fg="#404040",bg="white")
App_Title_label.place(x=315,y=100)


#app_logo
logo_image=PhotoImage(file="./assests/logo.png")
logo=Label(image=logo_image)
logo.place(x=300,y=130)

#bottom_box for wind humidity description and pressure
frame_image=PhotoImage(file="./assests/box.png")
frame_myimage=Label(image=frame_image)
frame_myimage.pack(padx=5,pady=5,side=BOTTOM)

#Date and Time Box
name = Label(root,font=("arial",15,'bold'))
name.place(x=30,y=100)
clock=Label(root,font=("Helvetica",20))
clock.place(x=30,y=200)



#label for Wind Humidity Description and Pressure Text
label1 = Label(root,text="WIND",font=("Helvetica",15,"bold"),fg="white",bg="#1ab5ef")
label1.place(x=120,y=400)

label2 = Label(root,text="HUMIDITY",font=("Helvetica",15,"bold"),fg="white",bg="#1ab5ef")
label2.place(x=250,y=400)

label3 = Label(root,text="DESCRIPTION",font=("Helvetica",15,"bold"),fg="white",bg="#1ab5ef")
label3.place(x=430,y=400)

label4 = Label(root,text="PRESSURE",font=("Helvetica",15,"bold"),fg="white",bg="#1ab5ef")
label4.place(x=650,y=400)


#label for Wind Humidity Description and Pressure Values
t = Label(font=("arial",70,"bold"),fg="#ee666d")
t.place(x=600,y=150)

c=Label(font=("arial",15,'bold'))
c.place(x=600,y=250)

w=Label(text="...",font=("arial",15,'bold'),bg="#1ab5ef")
w.place(x=120,y=430)

h=Label(text="...",font=("arial",15,'bold'),bg="#1ab5ef")
h.place(x=250,y=430)

d=Label(text="...",font=("arial",15,'bold'),bg="#1ab5ef")
d.place(x=430,y=430)

p=Label(text="...",font=("arial",15,'bold'),bg="#1ab5ef")
p.place(x=650,y=430)



root.mainloop() 